import os
import re
import subprocess
import sys

def get_chrome_version():
    try:
        # For Windows
        if sys.platform.startswith('win'):
            try:
                # Try registry query first
                stream = os.popen(r'reg query "HKLM\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\Google Chrome"')
                output = stream.read()
                version = re.findall("DisplayVersion    REG_SZ    (.*)", output)
                if version:
                    return version[0]
            except:
                pass
            
            # If registry query fails, try direct path
            paths = [
                r'C:\Program Files\Google\Chrome\Application\chrome.exe',
                r'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe',
                os.path.expanduser(r'~\AppData\Local\Google\Chrome\Application\chrome.exe'),
            ]
            
            for path in paths:
                if os.path.exists(path):
                    try:
                        info = subprocess.check_output(f'wmic datafile where name="{path.replace(os.sep, os.sep+os.sep)}" get Version /value', shell=True)
                        version = re.search(b'Version=(.+)', info)
                        if version:
                            return version.group(1).decode('utf-8').strip()
                    except:
                        continue

        return "Chrome not found"
    
    except Exception as e:
        return f"Error detecting Chrome version: {str(e)}"

if __name__ == "__main__":
    version = get_chrome_version()
    print("\nGoogle Chrome Version Check")
    print("=" * 25)
    print(f"Installed version: {version}")
    
    if version == "Chrome not found":
        print("\nERROR: Google Chrome is not installed. Please install Chrome before proceeding.")
    else:
        print("\nNext steps:")
        print("1. Make sure Chrome is up to date by opening Chrome and going to:")
        print("   Menu (⋮) > Help > About Google Chrome")
        print("2. After confirming/updating Chrome, run:")
        print("   pip install -r requirements.txt")
        print("\nPress Enter to exit...") 