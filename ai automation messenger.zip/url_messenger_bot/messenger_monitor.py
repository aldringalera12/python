import tkinter as tk
from tkinter import messagebox, scrolledtext
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
import time
import os
import sys
import threading
import queue
import logging
from datetime import datetime
from selenium.webdriver.chrome.service import Service as ChromeService
import random
import json
import http.client
import urllib.parse

class MessengerMonitor:
    def __init__(self):
        self.setup_logging()
        self.root = tk.Tk()
        self.root.title("Messenger Conversation Monitor")
        self.root.geometry("800x600")
        
        # Message queue for thread communication
        self.message_queue = queue.Queue()
        
        # Main container
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # URL Entry Frame
        self.url_frame = tk.Frame(self.main_frame)
        self.url_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.url_label = tk.Label(self.url_frame, text="Messenger Conversation URL:")
        self.url_label.pack(side=tk.LEFT)
        
        self.url_entry = tk.Entry(self.url_frame, width=50)
        self.url_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # API Key Entry Frame
        self.api_frame = tk.Frame(self.main_frame)
        self.api_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.api_label = tk.Label(self.api_frame, text="HuggingFace Token:")
        self.api_label.pack(side=tk.LEFT)
        
        self.api_entry = tk.Entry(self.api_frame, width=50, show="*")
        self.api_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        # Pre-fill with the user's token
        self.api_entry.insert(0, "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")
        
        # Control Frame
        self.control_frame = tk.Frame(self.main_frame)
        self.control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Status Label
        self.status_label = tk.Label(self.control_frame, text="Status: Ready", font=("Arial", 10))
        self.status_label.pack(side=tk.LEFT)
        
        # Button Frame (right side)
        self.button_frame = tk.Frame(self.control_frame)
        self.button_frame.pack(side=tk.RIGHT)
        
        # Continue Button (initially hidden)
        self.continue_button = tk.Button(self.button_frame, text="Continue Monitoring", command=self.continue_monitoring)
        
        # Run Button
        self.run_button = tk.Button(self.button_frame, text="Start Monitor", command=self.start_monitoring_thread)
        self.run_button.pack(side=tk.RIGHT)
        
        # Stop Button (initially disabled)
        self.stop_button = tk.Button(self.button_frame, text="Stop Monitor", command=self.stop_monitoring, state=tk.DISABLED)
        self.stop_button.pack(side=tk.RIGHT, padx=5)
        
        # Log Text Area
        self.log_frame = tk.LabelFrame(self.main_frame, text="Logs")
        self.log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = scrolledtext.ScrolledText(self.log_frame, height=20)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.driver = None
        self.is_monitoring = False
        self.monitor_thread = None
        self.waiting_for_login = False
        self.last_message_id = None
        self.processed_messages = set()
        self.replied_messages = set()  # New set to track messages we've replied to
        self.conversation_history = []  # Store recent messages for context
        
        # Start message processing
        self.root.after(100, self.process_message_queue)
        
        # Initialize fallback responses
        self.initialize_fallback_responses()

    def initialize_fallback_responses(self):
        """Initialize fallback responses if API fails"""
        # Fallback responses
        self.fallback_responses = [
            "Thanks for your message! I'll get back to you soon.",
            "I received your message and will respond shortly.",
            "Thanks for reaching out! Let me check and get back to you.",
            "I appreciate your message. I'll follow up with you soon.",
            "I'm currently away but will respond as soon as possible."
        ]
        
        # Smart pattern-based responses
        self.greeting_responses = [
            "Hello there! How can I help you today?",
            "Hi! Nice to hear from you.",
            "Hey! What can I do for you?",
            "Hello! How are you doing today?",
            "Hi there! How may I assist you?"
        ]
        
        self.question_responses = [
            "That's a good question. Let me look into that for you.",
            "I'd be happy to help with that question.",
            "Interesting question! I'll find that information for you.",
            "I'll need to check on that. Can I get back to you shortly?",
            "Great question! Let me see what I can find out."
        ]
        
        self.thanks_responses = [
            "You're welcome! Let me know if you need anything else.",
            "Happy to help! Is there anything else you'd like to know?",
            "My pleasure! Feel free to ask if you have other questions.",
            "Glad I could assist! Don't hesitate to reach out for more help.",
            "Anytime! I'm here if you need further assistance."
        ]

    def process_message_queue(self):
        """Process messages from the queue"""
        try:
            while True:
                message = self.message_queue.get_nowait()
                if isinstance(message, dict):
                    if message.get('type') == 'new_message':
                        self.show_new_message_notification(message.get('message_info', {}))
                    elif message.get('type') == 'status':
                        self.status_label.config(text=f"Status: {message.get('text', '')}")
                    elif message.get('type') == 'log':
                        self.log_message(message.get('text', ''), message.get('level', logging.INFO))
        except queue.Empty:
            pass
        finally:
            # Schedule the next check
            self.root.after(100, self.process_message_queue)

    def show_new_message_notification(self, message_info):
        """Show new message notification in the GUI thread"""
        try:
            timestamp = message_info.get('timestamp', datetime.now().strftime("%H:%M:%S"))
            msg = f"New message at {timestamp}: {message_info['text'][:50]}..."
            self.status_label.config(text=f"Status: {msg}")
            self.log_message(msg)
            
            # Add message to processed messages
            self.processed_messages.add(message_info['id'])
        except Exception as e:
            self.queue_log(f"Error showing notification: {str(e)}", logging.ERROR)

    def update_status(self, text):
        """Add status update to queue"""
        self.message_queue.put({'type': 'status', 'text': text})

    def queue_log(self, text, level=logging.INFO):
        """Add log message to queue"""
        self.message_queue.put({'type': 'log', 'text': text, 'level': level})

    def setup_logging(self):
        self.logger = logging.getLogger('MessengerMonitor')
        self.logger.setLevel(logging.INFO)
        
        # Create logs directory if it doesn't exist
        if not os.path.exists('logs'):
            os.makedirs('logs')
            
        # File handler
        log_file = f'logs/messenger_monitor_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)
        
        # Formatters
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        
        self.logger.addHandler(file_handler)

    def log_message(self, message, level=logging.INFO):
        self.logger.log(level, message)
        self.log_text.insert(tk.END, f"{datetime.now().strftime('%H:%M:%S')} - {message}\n")
        self.log_text.see(tk.END)
        self.root.update_idletasks()

    def setup_driver(self):
        try:
            self.log_message("Setting up Chrome driver...")
            options = webdriver.ChromeOptions()
            options.add_argument('--start-maximized')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_experimental_option('excludeSwitches', ['enable-logging'])
            
            # Get Chrome version
            chrome_version = self.get_chrome_version()
            if not chrome_version:
                self.log_message("Could not detect Chrome version", logging.ERROR)
                messagebox.showerror("Error", "Could not detect Chrome version. Please make sure Chrome is installed.")
                return None
            
            self.log_message(f"Detected Chrome version: {chrome_version}")
                
            try:
                service = ChromeService()
                driver = webdriver.Chrome(service=service, options=options)
                self.log_message("Chrome driver setup successful")
                return driver
            except Exception as e:
                error_msg = str(e)
                if "This version of ChromeDriver only supports Chrome version" in error_msg:
                    self.log_message(f"Chrome version mismatch: {error_msg}", logging.ERROR)
                    messagebox.showerror("Error", f"Chrome version mismatch. Please update Chrome or ChromeDriver.\nCurrent Chrome version: {chrome_version}")
                else:
                    self.log_message(f"Failed to initialize Chrome: {error_msg}", logging.ERROR)
                    messagebox.showerror("Error", f"Failed to initialize Chrome: {error_msg}")
                return None

        except Exception as e:
            self.log_message(f"Failed to setup Chrome: {str(e)}", logging.ERROR)
            messagebox.showerror("Error", f"Failed to setup Chrome: {str(e)}")
            return None

    def get_chrome_version(self):
        try:
            if sys.platform.startswith('win'):
                import winreg
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Software\Google\Chrome\BLBeacon')
                version, _ = winreg.QueryValueEx(key, 'version')
                return version
        except:
            return None
        return None

    def check_login_status(self):
        try:
            self.log_message("Checking login status...")
            # First check for login page elements
            try:
                login_elements = self.driver.find_elements(By.CSS_SELECTOR, 'input[type="password"]')
                if login_elements:
                    self.log_message("Login page detected")
                    return False
            except:
                pass

            # Then check for messenger elements
            try:
                WebDriverWait(self.driver, 5).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, 'div[role="main"]'))
                )
                self.log_message("User is logged in")
                return True
            except:
                pass

            self.log_message("Login status unclear - waiting for user action")
            return None

        except Exception as e:
            self.log_message(f"Error checking login status: {str(e)}")
            return None

    def get_latest_messages(self):
        try:
            # Wait for messages container
            messages_container = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'div[role="main"]'))
            )
            
            # Wait a bit to ensure messages are loaded
            time.sleep(1)
            
            try:
                # Get message elements using the exact class
                message_elements = messages_container.find_elements(
                    By.CSS_SELECTOR, 
                    'div.xexx8yu.x4uap5.x18d9i69.xkhd6sd.x1gslohp.x11i5rnm.x12nagc.x1mh8g0r.x1yc453h.x126k92a.x18lvrbx'
                )
                
                current_time = datetime.now()
                message_details = []
                processed_texts = set()  # To avoid duplicate messages
                
                if not message_elements:
                    self.queue_log("No message elements found with CSS selector", logging.DEBUG)
                    return []
                
                # Process only the very last message to avoid responding to previous chats
                last_messages = message_elements[-3:]  # Get last 3 messages for context
                
                for msg_elem in last_messages:
                    try:
                        # Get the message text content
                        msg_text = msg_elem.text.strip()
                        if not msg_text:
                            continue
                            
                        # Find the timestamp element
                        try:
                            # Look for timestamp in nearby elements
                            timestamp_elem = msg_elem.find_element(By.XPATH, 
                                './following::span[contains(@class, "x186z157") and contains(@class, "xk50ysn")][1]')
                            timestamp_text = timestamp_elem.text.strip()
                        except:
                            # If can't find timestamp after the message, try looking before it
                            try:
                                timestamp_elem = msg_elem.find_element(By.XPATH, 
                                    './preceding::span[contains(@class, "x186z157") and contains(@class, "xk50ysn")][1]')
                                timestamp_text = timestamp_elem.text.strip()
                            except:
                                # If still no timestamp found, use current time
                                timestamp_text = current_time.strftime("%I:%M %p")
                        
                        # Check for UI element text like "Enter", "Profile", etc.
                        ui_elements = {'Enter', 'Profile', 'Mute', 'Search', 'Chat info', 
                                     'Customize chat', 'Media, files and links', 'Privacy & support',
                                     'Sent', 'Delivered', 'Read', 'Seen', '...'}
                        if msg_text in ui_elements or len(msg_text) <= 1:
                            continue
                            
                        # Skip if we've already processed this text in this batch
                        if msg_text in processed_texts:
                            continue
                        processed_texts.add(msg_text)
                        
                        # Create a consistent message ID based on text content
                        msg_id = f"{hash(msg_text)}"
                        
                        # If this is a new message we haven't processed
                        if msg_id not in self.processed_messages and msg_id not in self.replied_messages:
                            message_details.append({
                                'id': msg_id,
                                'text': msg_text,
                                'timestamp': timestamp_text
                            })
                            self.queue_log(f"Found message: '{msg_text}' at {timestamp_text}", logging.DEBUG)
                    
                    except Exception as e:
                        self.queue_log(f"Error processing message element: {str(e)}", logging.DEBUG)
                        continue
                
                # Only return the very last message that's new to ensure one response per chat
                if message_details:
                    self.queue_log(f"Found {len(message_details)} new messages", logging.DEBUG)
                    return [message_details[-1]]  # Only return the very last message
                else:
                    self.queue_log("No new messages found", logging.DEBUG)
                    return []
                
            except Exception as e:
                self.queue_log(f"Error finding messages: {str(e)}", logging.DEBUG)
                return []
            
        except Exception as e:
            self.queue_log(f"Error getting messages: {str(e)}", logging.ERROR)
            return []

    def start_monitoring_thread(self):
        self.monitor_thread = threading.Thread(target=self.start_monitoring)
        self.monitor_thread.daemon = True
        self.monitor_thread.start()
        self.run_button.config(state=tk.DISABLED)

    def continue_monitoring(self):
        self.waiting_for_login = False
        self.continue_button.pack_forget()
        self.stop_button.config(state=tk.NORMAL)
        self.queue_log("Continuing monitoring after login")
        self.start_message_monitoring()

    def stop_monitoring(self):
        self.log_message("Stopping monitor...")
        self.is_monitoring = False
        self.waiting_for_login = False
        if self.driver:
            self.driver.quit()
            self.driver = None
        self.run_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.continue_button.pack_forget()
        self.status_label.config(text="Status: Ready")
        self.log_message("Monitor stopped")

    def get_ai_response(self, message_text):
        """Generate an AI response using HuggingFace Inference API or smart fallbacks"""
        try:
            # Add message to conversation history for context
            self.conversation_history.append({"role": "user", "content": message_text})
            
            # Keep only last 10 messages for context
            if len(self.conversation_history) > 10:
                self.conversation_history = self.conversation_history[-10:]
            
            # Try to use free HuggingFace API first
            try:
                # Get the API token from the entry field (optional)
                api_token = self.api_entry.get().strip()
                
                # Prepare the conversation context with clear instructions
                system_instruction = "You are a helpful assistant responding to messages on Facebook Messenger. Keep your responses short, direct, and relevant to the user's message. Focus specifically on addressing what they're asking."
                conversation = system_instruction + "\n\n"
                
                # Add recent conversation history for context
                for i, msg in enumerate(self.conversation_history[-5:]):
                    role = "User" if msg["role"] == "user" else "Assistant"
                    conversation += f"{role}: {msg['content']}\n"
                
                # Add the current request with clear instruction
                prompt = f"{conversation}\nAssistant (respond directly to the last message in 1-2 sentences):"
                
                # Set up the HTTP connection to HuggingFace's Inference API
                conn = http.client.HTTPSConnection("api-inference.huggingface.co")
                
                # Build payload with the model and prompt
                payload = json.dumps({
                    "inputs": prompt,
                    "parameters": {
                        "max_new_tokens": 100,
                        "temperature": 0.5,  # Lower temperature for more focused responses
                        "return_full_text": False,
                        "do_sample": True
                    }
                })
                
                # Set up headers
                headers = {'Content-Type': 'application/json'}
                if api_token:  # Add token if provided
                    headers['Authorization'] = f'Bearer {api_token}'
                
                # API endpoint for free Mistral-7B model
                endpoint = "/models/mistralai/Mistral-7B-Instruct-v0.2"
                
                # Make the request
                conn.request("POST", endpoint, payload, headers)
                
                # Get response
                response = conn.getresponse()
                response_data = json.loads(response.read().decode())
                conn.close()
                
                # Extract the generated text
                if isinstance(response_data, list) and len(response_data) > 0:
                    generated_text = response_data[0].get('generated_text', '').strip()
                elif isinstance(response_data, dict):
                    generated_text = response_data.get('generated_text', '').strip()
                else:
                    generated_text = ''
                    
                # If we got a good response, clean it up and use it
                if generated_text:
                    # Clean up the response - remove any prefixes
                    generated_text = generated_text.replace("Assistant:", "").replace("Assistant (respond directly to the last message in 1-2 sentences):", "").strip()
                    
                    # Check for response quality
                    if len(generated_text) < 5 or "I'll help" in generated_text and len(generated_text) > 100:
                        # If response seems generic or too short, use better pattern matching
                        self.queue_log("API response was low quality, using improved pattern matching", logging.INFO)
                        return self.get_improved_pattern_response(message_text)
                    
                    # Clean up and truncate if too long
                    if len(generated_text) > 150:
                        generated_text = generated_text[:150]
                    
                    # Add the response to conversation history
                    self.conversation_history.append({"role": "assistant", "content": generated_text})
                    return generated_text
                
                # If API request failed or returned empty text, use pattern-based responses
                self.queue_log("Using improved pattern response due to empty API result", logging.INFO)
                return self.get_improved_pattern_response(message_text)
                
            except Exception as api_error:
                self.queue_log(f"HuggingFace API error: {str(api_error)}", logging.ERROR)
                # If API fails, fall back to pattern-based responses
                return self.get_improved_pattern_response(message_text)
            
        except Exception as e:
            self.queue_log(f"Error in AI response generation: {str(e)}", logging.ERROR)
            return self.get_improved_pattern_response(message_text)
    
    def get_improved_pattern_response(self, message_text):
        """Generate a more accurate response based on message content"""
        message_lower = message_text.lower()
        
        # Check for help requests
        if "help" in message_lower or "assist" in message_lower or "need" in message_lower:
            return "I'd be happy to help. What specific assistance do you need?"
            
        # Check for greeting
        elif any(word in message_lower for word in ["hello", "hi", "hey", "greetings"]):
            return "Hello! How can I help you today?"
            
        # Check for question
        elif "?" in message_text or any(word in message_lower for word in ["what", "how", "when", "where", "why", "who"]):
            return "I'll answer your question as best I can. Could you provide a bit more detail?"
            
        # Check for thanks
        elif any(word in message_lower for word in ["thank", "thanks", "appreciate"]):
            return "You're welcome! Let me know if you need anything else."
            
        # Check for short messages that might need clarification
        elif len(message_text) < 10:
            return "I see your message. Could you tell me more about what you need?"
            
        # Default response that acknowledges receiving the message but is still relevant
        else:
            return "I've received your message. How can I help you with this?"

    def send_message(self, message_text):
        """Send a message in the conversation"""
        try:
            # Find and click the message input box
            message_box = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'div[contenteditable="true"]'))
            )
            message_box.click()
            
            # Type the message
            message_box.send_keys(message_text)
            
            # Press Enter to send
            message_box.send_keys(u'\ue007')  # Unicode for ENTER key
            
            self.queue_log(f"Sent auto-reply: {message_text}", logging.DEBUG)
            return True
        except Exception as e:
            self.queue_log(f"Error sending message: {str(e)}", logging.ERROR)
            return False

    def start_message_monitoring(self):
        """Start message monitoring in a separate thread"""
        def monitor_messages():
            try:
                self.update_status("Successfully logged in, monitoring for new messages...")
                self.queue_log("Starting message monitoring")
                
                self.processed_messages.clear()  # Reset processed messages
                self.replied_messages.clear()    # Reset replied messages
                self.conversation_history = []   # Reset conversation history
                self.is_monitoring = True
                last_replied_id = None  # Track the last message we replied to
                
                # Wait longer for initial page load and message rendering
                time.sleep(5)  # Increased wait time for initial load
                
                # Initial message load - mark existing messages as processed without replying
                initial_messages = self.get_latest_messages()
                self.queue_log(f"Found {len(initial_messages)} initial messages")
                
                # Process initial messages - just mark them as read without replying
                for message in initial_messages:
                    self.processed_messages.add(message['id'])
                    self.replied_messages.add(message['id'])  # Mark initial messages as replied to
                    # Add to conversation history for context
                    self.conversation_history.append({"role": "user", "content": message['text']})
                    self.queue_log(f"Marked as read: {message['text'][:50]}... from {message['timestamp']}", logging.DEBUG)
                
                # Keep only last 5 initial messages for context
                if len(self.conversation_history) > 5:
                    self.conversation_history = self.conversation_history[-5:]
                
                # Add a small delay after processing initial messages
                time.sleep(1)
                
                # Set a flag to indicate we're now actively monitoring
                monitoring_started = True
                self.queue_log("Now monitoring for new messages...")
                
                # Variable to track if we're currently processing messages
                is_processing = False
                
                while self.is_monitoring:
                    try:
                        # Only get new messages if we're not already processing
                        if not is_processing:
                            is_processing = True
                            current_messages = self.get_latest_messages()
                            
                            # Process validated messages (should only be one at most)
                            if current_messages:
                                for message in current_messages:
                                    # Skip this message if it's the same as the last one we replied to
                                    if last_replied_id == message['id']:
                                        continue
                                        
                                    # Double check it's not already processed
                                    if message['id'] not in self.processed_messages and message['id'] not in self.replied_messages:
                                        # Show notification for new messages
                                        self.queue_log(f"New message detected at {message['timestamp']}: {message['text'][:50]}...")
                                        self.message_queue.put({
                                            'type': 'new_message',
                                            'message_info': message
                                        })
                                        
                                        # Only send auto-reply if this is a new message we haven't replied to
                                        if (monitoring_started and len(message['text']) > 1):
                                            # Generate AI response based on message content
                                            ai_response = self.get_ai_response(message['text'])
                                            
                                            # Send the AI-generated response
                                            self.send_message(ai_response)
                                            self.queue_log(f"Sent AI reply to message: {message['text'][:30]}... => {ai_response[:50]}")
                                            
                                            # Add to conversation history
                                            self.conversation_history.append({"role": "assistant", "content": ai_response})
                                            
                                            # Update the last replied message
                                            last_replied_id = message['id']
                                            
                                            # Mark as replied immediately
                                            self.replied_messages.add(message['id'])
                                        
                                        # Mark as processed
                                        self.processed_messages.add(message['id'])
                            
                            is_processing = False
                        
                        # Sleep longer to reduce chance of multiple cycles catching same message
                        time.sleep(1.0)  # Check every 1 second for better consistency
                    except Exception as e:
                        self.queue_log(f"Error while monitoring: {str(e)}", logging.ERROR)
                        is_processing = False
                        time.sleep(1)  # Wait a bit longer on error
                        
            except Exception as e:
                self.queue_log(f"Error in message monitoring: {str(e)}", logging.ERROR)
                self.is_monitoring = False

        # Start monitoring in a separate thread
        monitor_thread = threading.Thread(target=monitor_messages, daemon=True)
        monitor_thread.start()

    def start_monitoring(self):
        url = self.url_entry.get().strip()
        if not url:
            self.log_message("No URL provided", logging.ERROR)
            messagebox.showerror("Error", "Please enter a Messenger conversation URL")
            self.run_button.config(state=tk.NORMAL)
            return

        if not url.startswith("https://www.messenger.com/"):
            self.log_message("Invalid URL format", logging.ERROR)
            messagebox.showerror("Error", "Please enter a valid Messenger conversation URL")
            self.run_button.config(state=tk.NORMAL)
            return

        try:
            if not self.driver:
                self.driver = self.setup_driver()
                if not self.driver:
                    self.run_button.config(state=tk.NORMAL)
                    return
            
            self.log_message(f"Navigating to URL: {url}")
            self.driver.get(url)
            self.status_label.config(text="Status: Checking login status...")
            
            # Check if logged in
            login_status = self.check_login_status()
            
            if login_status is False:  # Not logged in
                self.status_label.config(text="Status: Please log in to continue")
                self.log_message("Login required - waiting for user to log in")
                self.waiting_for_login = True
                
                # Show continue button and hide others
                self.continue_button.pack(side=tk.RIGHT, padx=5)
                self.stop_button.pack_forget()
                
                # Start a thread to check for login completion
                threading.Thread(target=self.check_login_completion, daemon=True).start()
                
            elif login_status is True:  # Already logged in
                self.start_message_monitoring()
            else:  # Unclear status
                self.status_label.config(text="Status: Please log in if needed and click Continue")
                self.log_message("Login status unclear - waiting for user action")
                self.continue_button.pack(side=tk.RIGHT, padx=5)
                
        except Exception as e:
            error_msg = f"An error occurred: {str(e)}"
            self.status_label.config(text=f"Status: Error")
            self.log_message(error_msg, logging.ERROR)
            messagebox.showerror("Error", error_msg)
            self.run_button.config(state=tk.NORMAL)

    def check_login_completion(self):
        """Check for login completion in a separate thread"""
        while self.waiting_for_login and self.driver:
            try:
                login_status = self.check_login_status()
                if login_status is True:
                    self.queue_log("Login detected automatically")
                    self.root.after(0, self.continue_monitoring)
                    break
                time.sleep(2)
            except:
                pass

    def run(self):
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.mainloop()

    def on_closing(self):
        self.stop_monitoring()
        self.root.destroy()

    def __del__(self):
        self.stop_monitoring()

if __name__ == "__main__":
    app = MessengerMonitor()
    app.run() 