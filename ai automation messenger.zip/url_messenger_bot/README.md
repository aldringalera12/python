# Messenger Conversation Monitor

A Python application that monitors Facebook Messenger conversations for new messages using a simple GUI interface.

## Features

- GUI interface for easy URL input
- Automatic login detection
- Real-time message monitoring
- New message notifications
- Chrome browser automation

## Requirements

- Python 3.7 or higher
- Google Chrome browser
- Internet connection

## Installation

1. Install the required packages:
```bash
pip install -r requirements.txt
```

## Usage

1. Run the application:
```bash
python messenger_monitor.py
```

2. Enter a Messenger conversation URL in the format: `https://www.messenger.com/t/[conversation-id]`

3. Click "Run Monitor"

4. If you're not logged in to Facebook, the application will prompt you to log in first

5. Once logged in, the application will start monitoring for new messages

## Notes

- The application requires you to be logged into Facebook Messenger
- Keep the browser window open while monitoring
- The application checks for new messages every 2 seconds
- You will receive a notification when new messages are detected 